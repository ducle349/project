import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { ShoeAPIs } from "../../../apis/ShoesApis";
const initialState = {
  isLoading: false,
  shoes: [],
  currentShoe: {},
  errors: {},
  pagination: {
    currentPage: 1,
    limitPerPage: 8,
    total: 8,
  },
  searchKey: "",
  params: {
    _sort: null,
    _order: null,
    brand: null,
    q: null,
    price_lte: null,
    price_gte: null,
  },
};
export const actFetchAllShoe = createAsyncThunk(
  "shoes/fetchAllShoe",
  async (params = {}) => {
    const response = await ShoeAPIs.getAllShoes({
      _sort: "createAt",
      _order: "desc",
      ...params,
    });
    return {
      data: response.data,
      total: response.headers.get("X-Total-Count"),
    };
  }
);
export const actFetchShoeById = createAsyncThunk(
  "shoes/fetchShoeById",
  async (shoeId) => {
    const shoe = await ShoeAPIs.getShoeById(shoeId);
    return shoe;
  }
);
const shoeSlice = createSlice({
  name: "shoes",
  initialState: initialState,
  reducers: {
    actSetShoes: (state, action) => {
      state.shoes = action.payload;
    },
    setLoading: (state, action) => {
      state.isLoading = action.payload;
    },
    actSetErrors: (state, action) => {
      state.errors = action.payload;
    },
    setNewPage: (state, action) => {
      state.pagination = {
        ...state.pagination,
        currentPage: action.payload,
      };
    },
    setSearchKey: (state, action) => {
      state.searchKey = action.payload;
    },
    fiterProduct: (state, action) => {
      state.params.price_gte = action.payload[0];
      console.log("gte", action.payload[0]);
      state.params.price_lte = action.payload[1];
      console.log("lte", action.payload[1]);
    },
  },
  extraReducers: (builder) => {
    builder.addCase(actFetchAllShoe.pending, (state, action) => {
      state.isLoading = true;
    });
    builder.addCase(actFetchAllShoe.rejected, (state, action) => {
      state.errors = {};
      state.isLoading = false;
    });
    builder.addCase(actFetchAllShoe.fulfilled, (state, action) => {
      state.shoes = action.payload.data;
      state.isLoading = false;
      state.pagination.total = action.payload.total;
    });
    builder.addCase(actFetchShoeById.fulfilled, (state, action) => {
      state.currentShoe = action.payload;
      state.isLoading = false;
    });
  },
});

export const {
  actSetShoes,
  actSetErrors,
  setNewPage,
  setSearchKey,
  fiterProduct,
} = shoeSlice.actions;
export const shoeReducer = shoeSlice.reducer;
