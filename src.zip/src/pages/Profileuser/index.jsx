import { ScheduleOutlined } from "@ant-design/icons";
import { Button, Input } from "antd";
import { Controller, useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { ROUTES } from "../../constants/Routes";
import "./style.scss";
import { actupdateUserById } from "../../redux/features/users/userSlice";
const schema = Yup.object().shape({
  password: Yup.string().required("Please input name"),
  repassword: Yup.string().required("Please input password"),
});
const ProfileUser = () => {
  const { userInfo, isAuth } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const methods = useForm({
    defaultValues: {
      password: "",
      repassword: "",
    },
    resolver: yupResolver(schema),
  });
  const {
    handleSubmit,
    control,
    formState: { errors },
  } = methods;
  const onValid = (values) => {
    console.log(values.password);
    const userchangepassword = {
      name: userInfo[0].name,
      numberphone: userInfo[0].numberphone,
      address: userInfo[0].address,
      email: userInfo[0].email,
      password: values.password,
      id: userInfo[0].id,
    };
    console.log("dfg", userchangepassword);
    dispatch(
      actupdateUserById({
        id: userInfo[0].id,
        usersUpdate: userchangepassword,
      })
    );
  };
  return (
    <>
      <div className="main-profile">
        <div>
          <h3>Thông tin cá nhân</h3>
          <div>Họ Và Tên: {isAuth ? userInfo[0].name : ""}</div>
          <div>Địa Chỉ: {isAuth ? userInfo[0].address : ""}</div>
        </div>
        <div>
          <h3>Thông tin tài khoản</h3>
          <div
            style={{
              backgroundColor: "red",
              color: "white",
              padding: 5,
              textAlign: "center",
            }}
          >
            <label for="btn_password" className="label-pass">
              Đổi mật khẩu
            </label>
            <input type="checkbox" id="btn_password"></input>
            {isAuth ? (
              <div className="block_changepass">
                <form onSubmit={handleSubmit(onValid)}>
                  <div>
                    <label for="btn_password" className="delete_block">
                      X
                    </label>
                    <div className="input-login">
                      <div className="input-form__item">
                        <label
                          className="input-form__label"
                          style={{ minWidth: 100 }}
                        >
                          Password:
                        </label>
                        <Controller
                          control={control}
                          name="password"
                          type="password"
                          render={({ field }) => {
                            return <Input placeholder="password" {...field} />;
                          }}
                        />
                      </div>
                      {!!errors.password?.message && (
                        <span style={{ color: "red" }}>
                          {errors.password?.message}
                        </span>
                      )}
                      <div className="input-form__item">
                        <label
                          className="input-form__label"
                          style={{ minWidth: 100 }}
                        >
                          RePassword:
                        </label>
                        <Controller
                          control={control}
                          name="repassword"
                          render={({ field }) => {
                            return (
                              <Input
                                type="password"
                                placeholder="Re-Password"
                                {...field}
                              />
                            );
                          }}
                        />
                      </div>
                      {!!errors.repassword?.message && (
                        <span style={{ color: "red" }}>
                          {errors.repassword?.message}
                        </span>
                      )}
                    </div>
                    <Button className="input-form__btn" htmlType="submit">
                      Đổi mật khẩu
                    </Button>
                  </div>
                </form>
              </div>
            ) : (
              <div className="block_changepass">
                <label for="btn_password" className="delete_block">
                  X
                </label>
                <p>Vui lòng đăng nhập để dùng chức năng đổi mật khẩu</p>
              </div>
            )}
          </div>
        </div>
        <div>
          <h3>Đơn hàng của tôi</h3>
          <div style={{ display: "flex" }}>
            <p style={{ marginRight: 30 }}>Lịch sử mua hàng</p>
            <Link to={ROUTES.ODER_PAGE}>
              <ScheduleOutlined style={{ fontSize: "30px" }} />
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfileUser;
