import React from "react";
import Cart from "../../components/Cart";

import "./style.scss";
import { useDispatch, useSelector } from "react-redux";
import {
  actDeleteCart,
  actUpdateCart,
} from "../../redux/features/Carts/cartSlice";
import { Button } from "antd";
import { actCreateNewOder } from "../../redux/features/Oders/oderSlice";
import format from "date-fns/format";

const ShoppingCart = () => {
  const dispatch = useDispatch();
  const { userInfo, isAuth } = useSelector((state) => state.user);
  const handleDeleteCart = (id) => {
    dispatch(actDeleteCart(id));
  };
  const handleUpdateCart = (cartUpdate) => {
    dispatch(actUpdateCart(cartUpdate));
  };
  const { carts } = useSelector((state) => state.cart);
  const renderTasklist = () => {
    return carts.map((cart) => {
      return (
        <Cart
          key={cart.id}
          cart={cart}
          handleDeleteCart={handleDeleteCart}
          handleUpdateCart={handleUpdateCart}
        />
      );
    });
  };
  const Price = carts.map((item) => {
    return item.total;
  });
  let sumPrice = Price.reduce(function (accumulator, element) {
    return parseFloat(accumulator) + parseFloat(element);
  }, 0);
  const formatNumber = (price) => {
    let priceString = "";
    while (price > 0) {
      let div = price % 1000;
      price = Math.floor(price / 1000);
      if (price !== 0) {
        if (div < 10) {
          div = "00" + div;
        } else if (div < 100) {
          div = "0" + div;
        }
        priceString = "." + div + priceString;
      } else {
        priceString = div + priceString;
      }
    }
    return priceString;
  };

  const hanldeCreateOder = () => {
    const day = new Date();
    const dataOder = {
      carts: carts,
      idUser: userInfo[0].id,
      total: sumPrice,
      createAt: format(day, "dd/MM/yyyy"),
    };
    dispatch(actCreateNewOder(dataOder));
  };
  return (
    <>
      <div className="cart">
        <h2 className="cart-title">GIỎ HÀNG CỦA BẠN</h2>
        <div className="cart-content">
          <table className="table">
            <tbody>
              <tr>
                <td>Hình ảnh</td>
                <td>Tên sản phẩm</td>
                <td>Size</td>
                <td>Số lượng</td>
                <td>Đơn giá</td>
                <td>Tổng cộng</td>
                <td>Xóa</td>
              </tr>
              {renderTasklist(carts)}
            </tbody>
          </table>
          <div className="pay">
            <h5>THANH TOÁN ĐƠN HÀNG</h5>
            <p style={{ color: "red" }}>
              Tổng số tiền:{formatNumber(sumPrice) + "₫"}
            </p>
            <div
              style={{
                backgroundColor: "red",
                color: "white",
                padding: 5,
              }}
            >
              <label for="btn_pay">Thanh toán</label>
              <input type="checkbox" id="btn_pay"></input>
              {isAuth ? (
                <div className="block_pay">
                  <label for="btn_pay" className="delete_block">
                    X
                  </label>
                  <h3 className="block_pay_item"> Thông tin giao hàng</h3>
                  <div className="block_pay_item">Tên Người Nhận</div>
                  <input
                    className="block_pay_item"
                    defaultValue={isAuth ? userInfo[0].name : ""}
                  ></input>
                  <div className="block_pay_item">SĐT Người Nhận</div>
                  <input
                    className="block_pay_item"
                    defaultValue={isAuth ? userInfo[0].numberphone : ""}
                  ></input>
                  <div className="block_pay_item">Địa Chỉ Giao Hàng</div>
                  <input
                    className="block_pay_item"
                    defaultValue={isAuth ? userInfo[0].address : ""}
                  ></input>
                  <p className="block_pay_item" style={{ color: "red" }}>
                    Tổng số tiền:{formatNumber(sumPrice) + "₫"}
                  </p>
                  <Button className="block_pay_item" onClick={hanldeCreateOder}>
                    Mua hàng
                  </Button>
                </div>
              ) : (
                <div className="block_pay">
                  <label for="btn_pay" className="delete_block">
                    X
                  </label>
                  <p>Vui lòng đăng nhập để dùng chức năng thanh toán</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ShoppingCart;
