import React, { useState } from "react";
import { Input, Radio } from "antd";
import { Slider } from "antd";
import "./style.scss";
const Search = (props) => {
  const { handleSesrch } = props;
  const [searchPrice, setSearchPrice] = useState([]);

  const [searchSize, setSearchSize] = useState();
  const onChange = (e) => {
    setSearchSize(e.target.value);
  };
  const onChangeFilterPrice = (values) => {
    setSearchPrice(values);
    handleSesrch(searchPrice);
  };
  const formatNumber = (price) => {
    let priceString = "";
    while (price > 0) {
      let div = price % 1000;
      price = Math.floor(price / 1000);
      if (price !== 0) {
        if (div < 10) {
          div = "00" + div;
        } else if (div < 100) {
          div = "0" + div;
        }
        priceString = "." + div + priceString;
      } else {
        priceString = div + priceString;
      }
    }
    return priceString;
  };
  return (
    <>
      <div className="search">
        <div className="search__title">
          <h4>TÌM KIẾM SẢN PHẨM</h4>
        </div>
        <div className="search__slider">
          <div>GIÁ SẢN PHẨM</div>
          <Slider
            onChange={onChangeFilterPrice}
            range={{
              draggableTrack: true,
            }}
            defaultValue={[500000, 500000]}
            min={500000}
            max={5000000}
          />
          <div style={{ display: "flex", gap: 10, marginTop: 5 }}>
            <span>Từ</span>
            <Input
              value={formatNumber(searchPrice[0]) + " ₫"}
              style={{ color: "red", width: 100 }}
            />
            <span>Đến</span>
            <Input
              value={formatNumber(searchPrice[1]) + " ₫"}
              style={{ color: "red", width: 100 }}
            />
          </div>
        </div>
        <div className="search__size">
          <div className="search__size__title">SIZE</div>
          <Radio.Group
            className="search__size"
            onChange={onChange}
            value={searchSize}
          >
            <Radio value={39}>39</Radio>
            <Radio value={40}>40</Radio>
            <Radio value={41}>41</Radio>
            <Radio value={42}>42</Radio>
            <Radio value={43}>43</Radio>
          </Radio.Group>
        </div>
      </div>
    </>
  );
};

export default Search;
